select
    e.id as id1_1_,
    e.department_id as departme3_1_,
    e.username as username2_1_ 
from
    Employee e 
where
    e.id = 1

select
    d.id as id1_0_0_
from
    Department d
where
    d.id = 1